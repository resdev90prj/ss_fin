<?php

$config = [
    'app_name' => 'SaaS IA Finan',
    'base_path' => dirname(__DIR__),
    'base_url' => rtrim((isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/\\'),
    'db' => [
        'host' => getenv('DB_HOST') ?: '127.0.0.1',
        'port' => getenv('DB_PORT') ?: '3306',
        'name' => getenv('DB_NAME') ?: 'saas_ia_finan',
        'user' => getenv('DB_USER') ?: 'root',
        'pass' => getenv('DB_PASS') ?: '',
        'charset' => 'utf8mb4'
    ],
];

// Override opcional para separar ambiente local/producao sem mudar a arquitetura atual.
$customConfigPath = __DIR__ . '/config.custom.php';
if (is_file($customConfigPath)) {
    $customConfig = require $customConfigPath;
    if (is_array($customConfig)) {
        $config = array_replace_recursive($config, $customConfig);
    }
}

return $config;
